#include <boost/test/unit_test.hpp>
#include <engine/GameWorld.hpp>

BOOST_AUTO_TEST_SUITE(WorldTests)

BOOST_AUTO_TEST_CASE(world_object_destroy) {
}

BOOST_AUTO_TEST_SUITE_END()
