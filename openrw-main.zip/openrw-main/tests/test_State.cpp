#include <boost/test/unit_test.hpp>

BOOST_AUTO_TEST_SUITE(StateUnitTests)

BOOST_AUTO_TEST_SUITE_END()
