#ifndef GAME_HPP
#define GAME_HPP

#define GAME_TIMESTEP (1.f / 60.f)

#endif  // GAME_HPP
