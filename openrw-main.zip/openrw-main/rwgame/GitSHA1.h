extern const char* kGitSHA1Hash;
