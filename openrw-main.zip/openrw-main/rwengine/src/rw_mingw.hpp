#undef IGNORE
#undef near
#undef far
