#ifndef _RWENGINE_GTA3MODULE_HPP_
#define _RWENGINE_GTA3MODULE_HPP_
#include <script/ScriptModule.hpp>

class GTA3Module : public ScriptModule {
public:
    GTA3Module();
};

#endif
