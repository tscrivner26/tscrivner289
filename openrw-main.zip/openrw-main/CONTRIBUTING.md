# How to contribute

To find out how to report bugs or contribute code, please read the [contributing](https://github.com/rwengine/openrw/wiki/Contributing)
page. This page covers what types of contributions we are looking to encourage.

