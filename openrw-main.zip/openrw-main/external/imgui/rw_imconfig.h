#ifndef RW_IMCONFIG_H
#define RW_IMCONFIG_H

// Disable imgui assertions when not in debug mode
#ifndef RW_DEBUG
#define IM_ASSERT(MSG) //FIXME(madebr): remove comment
#endif

#endif // RW_IMCONFIG_H
